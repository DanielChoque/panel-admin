export class File {
    id:number
    type:string
    dateCreate:Date
    name:string
    image:Blob
    flag:number
    url:string
}
