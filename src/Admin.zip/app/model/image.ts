export class Image {
}
