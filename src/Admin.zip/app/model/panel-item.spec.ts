import { PanelItem } from './panel-item';

describe('PanelItem', () => {
  it('should create an instance', () => {
    expect(new PanelItem()).toBeTruthy();
  });
});
