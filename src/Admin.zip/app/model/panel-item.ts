export class PanelItem {
    id_panel:number
    name:string
    url_image:string
    father_id:number
    lavel:number
    url_pdf:string
    target:string
}
