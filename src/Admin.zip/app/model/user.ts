export class User {
    id:number
    name:string
    pasword:string
    token:string

}
